import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LogFileProcessor {

    private static final String JDBC_URL = "jdbc:mariadb://localhost:3306/logdb";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "root";
    private static final String LOG_FILE_PATH = "C:\\Users\\Aprelean\\Documents\\ΣΑΔΕ\\ALogFileLoad\\kk5502_access.2018-05-18.log";
    private static final String INSERT_SQL = "INSERT INTO transactions (SUserSessionID, BBytesSent, DMillisToProcess, tDateAndTime, aRemoteIPAddress, rFirstLineOfRequest, sHTTPStatusCode) VALUES (?, ?, ?, ?, ?, ?, ?)";

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             BufferedReader br = new BufferedReader(new FileReader(LOG_FILE_PATH))) {

            String line;
            Pattern pattern = Pattern.compile("");
            PreparedStatement pstmt = conn.prepareStatement(INSERT_SQL);

            while ((line = br.readLine()) != null) {
                Matcher matcher = pattern.matcher(line);
                if (matcher.find()) {
                    pstmt.setString(1, matcher.group(1)); // SUserSessionID
                    pstmt.setInt(2, Integer.parseInt(matcher.group(2))); // BBytesSent
                    pstmt.setInt(3, Integer.parseInt(matcher.group(3))); // DMillisToProcess
                    pstmt.setTimestamp(4, java.sql.Timestamp.valueOf(matcher.group(4))); // tDateAndTime
                    pstmt.setString(5, matcher.group(5)); // aRemoteIPAddress
                    pstmt.setString(6, matcher.group(6)); // rFirstLineOfRequest
                    pstmt.setInt(7, Integer.parseInt(matcher.group(7))); // sHTTPStatusCode
                    pstmt.executeUpdate();
                }
            }

        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
    }
}
